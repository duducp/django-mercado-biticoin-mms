# Write functions to help the views.py

from django.apps import AppConfig


class {{camel_case_app_name}}Config(AppConfig):
    name = 'apps.{{app_name}}'
    verbose_name = '{{camel_case_app_name}}'

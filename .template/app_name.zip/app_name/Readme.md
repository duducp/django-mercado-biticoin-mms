Hi, you just created an app with the name {{camel_case_app_name}}

The first step is to register it so that Django can detect your app.
To do this, go to "core/settings/base.py" and add the following line in LOCAL_APPS:
```
'project.{{app_name}}.apps.{{camel_case_app_name}}Config',
```

The next step is to configure the app's route in "urls.py" If you are using V1,
just add the following line just below "api_v1":
```
api_v1.add_router('{{app_name}}/', {{app_name}}_router),
```

Ah, don't forget to import the route:
```
from project.{{app_name}}.views import router as {{app_name}}_router
```

After these settings your new app is already configured and you can start writing code.

For more information you can access the main README of the project or consult the Django and Django Ninja documentation:
- https://www.djangoproject.com/
- https://django-ninja.rest-framework.com/

# Create the request body and response schemas
# https://django-ninja.rest-framework.com/tutorial

from http import HTTPStatus

from ninja import Router

from project.{{app_name}}.schemas import (
    {{camel_case_app_name}}OutSchema,
    {{camel_case_app_name}}InSchema
)

router = Router(tags=['{{app_name}}'])


@router.get(
    path='/',
    summary='{{camel_case_app_name}}',
    description='',
    response={
        HTTPStatus.OK: {{camel_case_app_name}}OutSchema,
    }
)
async def retrieve_{{app_name}}(request, text: str = 'world'):
    data = {
        'message': f'Hello {text}'
    }

    return HTTPStatus.OK, data


@router.post(
    path='/',
    summary='{{camel_case_app_name}}',
    description='',
    response={
        HTTPStatus.OK: {{camel_case_app_name}}OutSchema,
    }
)
async def create_{{app_name}}(request, payload: {{camel_case_app_name}}InSchema):
    return HTTPStatus.OK, payload.dict()

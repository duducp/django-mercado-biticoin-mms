# Register your models here for add in admin.
# https://docs.djangoproject.com/en/3.2/ref/contrib/admin

# Create the request body and response schemas
# https://django-ninja.rest-framework.com/tutorial/body
# https://django-ninja.rest-framework.com/tutorial/response-schema
# https://django-ninja.rest-framework.com/tutorial/django-pydantic/

from ninja import Schema


class {{camel_case_app_name}}OutSchema(Schema):
    message: str


class {{camel_case_app_name}}InSchema(Schema):
    message: str
